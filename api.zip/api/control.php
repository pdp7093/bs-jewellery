<?php

use function Laravel\Prompts\select;
include_once('model.php');

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
class control extends model
{
    function __construct()
    {
        model::__construct();
        $url = $_SERVER['PATH_INFO'];
        $secret_key = "KvQRLn3EIqrPWH2LKeWu";
        switch ($url) {
            //Register User 
            case '/Register':
                $arr = array(
                    "name" => $_POST["name"],
                    "email" => $_POST['email'],
                    "mobile_number" => $_POST['mobile'],
                    "password" => md5($_POST['password']),
                    "terms_cond" => $_POST['terms_cond']

                );
                $sel = $this->select_where("customers", array("email" => $_POST['email']));
                if (!$sel->num_rows) {


                    $insert = $this->insert("customers", $arr);
                    if ($insert or die("Insert Query Failed")) {
                        echo json_encode(array("message" => "User Inserted Successfully", "status" => true));
                    } else {
                        echo json_encode(array("message" => "User Contacts Not Inserted ", "status" => false));
                    }
                } else {
                    echo json_encode(["message" => "Please Select Unique Email", "status" => false]);
                }
                break;

            //Login User
            case '/Login':
                $data = json_decode(file_get_contents("php://input"), true);
                if (!$data) {
                    die("JSON Not Recived" . file_get_contents("php://input"));
                }
                $email = $data['email'];
                $password = md5($data['password']);

                $arr = array("email" => $email, "password" => $password);
                $login = $this->select_where("customers", $arr);
                $chk = $login->num_rows;
                if ($chk == 1) {
                    $row = $login->fetch_assoc();
                    $payload = [
                        "customer_data" => $row,
                        "iat" => time(),
                        "exp" => time() + 3600 // 1 ghante ke liye valid
                    ];

                    $jwt = JWT::encode($payload, $secret_key, 'HS256');
                    echo json_encode(["message" => "Login Success", "token" => $jwt, "status" => true]);
                } else {
                    echo json_encode(["message" => "Login Failed", "status" => false]);
                }
                break;

            //Customer Profile
            case '/Profile-api':
                $headers = getallheaders();
                $authHeader = $headers['Authorization'] ?? '';

                if ($authHeader) {
                    $arr = explode(" ", $authHeader);
                    $token = $arr[1] ?? '';

                    try {
                        $decoded = JWT::decode($token, new Key($secret_key, 'HS256'));

                        echo json_encode([
                            "status" => "success",
                            "data" => [
                                "customer_data" => $decoded->customer_data,
                                "message" => "Welcome to your profile!"
                            ]
                        ]);
                    } catch (Exception $e) {
                        echo json_encode([
                            "status" => "error",
                            "message" => "Invalid or expired token"
                        ]);
                    }
                } else {
                    echo json_encode([
                        "status" => "error",
                        "message" => "Authorization header missing"
                    ]);
                }

                break;



            //------------------Admin Side------------------------

            //Login Admin
            case '/Admin/Admin-Login':
                $data = json_decode(file_get_contents("php://input"), true);
                if (!$data) {
                    die("JSON Not Recived" . file_get_contents("php://input"));
                }
                $email = $data['email'];
                $password = md5($data['password']);

                $arr = array("email" => $email, "password" => $password);
                $login = $this->select_where("admin", $arr);
                $chk = $login->num_rows;
                if ($chk == 1) {
                    $row = $login->fetch_assoc();
                    echo json_encode(["message" => "Login Success", "data" => $row, "session_variable" => $row['email'], "status" => true]);
                } else {
                    echo json_encode(["message" => "Login Failed", "status" => false]);
                }
                break;

            // User Add and Manage

            case '/Admin/Manage_user':
                $res = $this->select("customers");
                if (!empty($res)) {
                    echo json_encode(array("data" => $res, "status" => true));
                } else {
                    echo json_encode(array("message" => "No Record Found", "status" => false));
                }

                break;

            case '/Admin/Add_user':
                $arr = array(
                    "name" => $_POST["name"],
                    "email" => $_POST['email'],
                    "mobile_number" => $_POST['mobile'],
                    "password" => md5($_POST['password']),
                    "terms_cond" => $_POST['terms_cond']

                );

                $insert = $this->insert("customers", $arr);
                if ($insert or die("Insert Query Failed")) {
                    echo json_encode(array("message" => "User Inserted Successfully", "status" => true));
                } else {
                    echo json_encode(array("message" => "User Contacts Not Inserted ", "status" => false));
                }
                break;

            case '/Admin/Delete_user':
                $id = $_GET['cust_id'];
                $where = array("cust_id" => $id);
                $res = $this->delete("customer", $where);
                if ($res) {
                    echo json_encode(["message" => "Customer Delete Successfully", "status" => true]);
                } else {
                    echo json_encode(["message" => "Customer Not Delete", "status" => false]);
                }
                break;

            case '/Admin/Update_user':
                $where = array("cust_id" => $_GET['cust_id']);
                $data = json_decode(file_get_contents("php://input"), true);
                $update = array("name" => $data['name'], "email" => $data['email'], "mobile_number" => $data['mobile_number']);

                $res = $this->update("customers", $update, $data);
                if ($res) {
                    echo json_encode(["message" => "User Data Update SuccessFully", "status" => true]);
                } else {
                    echo json_encode(["message" => "Not Update Due to Error", "status" => false]);
                }
                break;
            //Category Add And Manage

            case '/Admin/Add_Category':
                $data = json_decode(file_get_contents("php://input"), true);
                if (!$data) {
                    die("JSON Not Recived" . file_get_contents("php://input"));
                }
                $arr = array("category_name" => $data['category_name']);
                $cat = $this->insert("category", $arr);
                if ($cat or die("Insert Query Failed")) {
                    echo json_encode((["message" => "Category Created", "status" => true]));
                } else {
                    echo json_encode(["message" => "Category Not Created", "status" => false]);
                }

                break;

            //---------------------- View All category ------------

            case '/Admin/view_category':
                $res = $this->select("category");
                $count = count($res);
                if (!empty($res)) {
                    echo json_encode(["data" => $res, "status" => true]);
                } else {
                    echo json_encode(["message" => "No Record Found", "status" => false]);
                }
                break;

            //----------------- Delete Category ------------------
            case '/Admin/Delete_category':
                $id = $_GET['cate_id'];
                $where = array("cate_id" => $id);
                $res = $this->delete("category", $where);
                if ($res) {
                    echo json_encode(["message" => "Category Delete Successfully", "status" => true]);
                } else {
                    echo json_encode(["message" => "Category Not Delete", "status" => false]);
                }
                break;

            //----------------- Update Category ------------------
            case '/Admin/Update_category':
                $id = $_GET['cate_id'];
                $where = array("cate_id" => $id);
                $data = json_decode(file_get_contents("php://input"), true);
                $update = array("category_name" => $data['category_name']);
                $res = $this->update("category", $update, $where);
                if ($res) {
                    echo json_encode(["message" => "Category Update Successfully", "status" => true]);
                } else {
                    echo json_encode(["message" => "Category Not Update", "status" => false]);
                }
                break;

            //collection page
            case '/Admin/Add_collection':
                $data = json_decode(file_get_contents("php://input"), true);
                if (!$data) {
                    die("JSON Not Recived:" . file_get_contents("php://input"));
                }
                $arr = array("collection_name" => $data['collection_name']);
                $cal = $this->insert("collection", $arr);
                if ($cal or die("Insert Query Failed")) {
                    echo json_encode(["message" => "Collection Created.", "status" => true]);
                } else {
                    echo json_encode(["message" => "Collection Not Created.", "status" => false]);
                }
                break;

            //----------------- Delete Collection ------------------
            case '/Admin/Delete_collection':
                $id = $_GET['collection_id'];
                $where = array("collection_id" => $id);
                $res = $this->delete("collection", $where);
                if ($res) {
                    echo json_encode(["message" => "Category Delete Successfully", "status" => true]);
                } else {
                    echo json_encode(["message" => "Category Not Delete", "status" => false]);
                }
                break;



            //---------------------- View All Collection ------------

            case '/Admin/view_collection':
                $res = $this->select("collection");
                $count = count($res);
                if (!empty($res)) {
                    echo json_encode(["data" => $res, "status" => true]);
                } else {
                    echo json_encode(["message" => "No Record Found", "status" => false]);
                }
                break;

            case '/Admin/Update_collection':
                $id = $_GET['collection_id'];
                $where = array("collection_id" => $id);
                $data = json_decode(file_get_contents("php://input"), true);
                $update = array("collection_name" => $data['collection_name']);
                $res = $this->update("collection", $update, $where);
                if ($res) {
                    echo json_encode(["message" => "Collection Update Successfully", "status" => true]);
                } else {
                    echo json_encode(["message" => "Collection Not Update", "status" => false]);
                }
                break;

            //offer Add And Manage

            case '/Admin/Add_offer':
                $data = json_decode(file_get_contents("php://input"), true);
                if (!$data) {
                    die("JSON Not Received: " . file_get_contents("php://input"));
                }

                $arr = array(
                    "offer_title"       => $data['offer_title'],
                    "offer_description" => $data['offer_description'],
                    "offer_code"        => $data['offer_code'],
                    "discount_type"     => $data['discount_type'],
                    "discount_value"    => $data['discount_value'],
                    "start_date"        => $data['start_date'],
                    "end_date"          => $data['end_date'],
                    "created_at"        => date("Y-m-d H:i:s")
                );

                $off = $this->insert("offer", $arr);

                if ($off) {
                    echo json_encode(["message" => "Offer Created", "status" => true]);
                } else {
                    echo json_encode(["message" => "Offer Not Created", "status" => false]);
                }
                break;


            //---------------------- View All Offer ------------

            case '/Admin/view_offer':
                $res = $this->select("offer");
                $count = count($res);
                if (!empty($res)) {
                    echo json_encode(["data" => $res, "status" => true]);
                } else {
                    echo json_encode(["message" => "No Record Found", "status" => false]);
                }
                break;

            //----------------- Delete Offer ------------------
            case '/Admin/Delete_offer':
                $id = $_GET['offer_id'];
                $where = array("offer_id" => $id);
                $res = $this->delete("offer", $where);
                if ($res) {
                    echo json_encode(["message" => "Offer Delete Successfully", "status" => true]);
                } else {
                    echo json_encode(["message" => "Offer Not Delete", "status" => false]);
                }
                break;
            //----------------- Update Offer ------------------
            case '/Admin/Update_offer':
                $id = $_GET['offer_id'];
                $where = array("offer_id" => $id);
                $data = json_decode(file_get_contents("php://input"), true);
                $update = array(
                    "offer_title"       => $data['offer_title'],
                    "offer_description" => $data['offer_description'],
                    "offer_code"        => $data['offer_code'],
                    "discount_type"     => $data['discount_type'],
                    "discount_value"    => $data['discount_value'],
                    "start_date"        => $data['start_date'],
                    "end_date"          => $data['end_date']
                );
                $res = $this->update("offer", $update, $where);
                if ($res) {
                    echo json_encode(["message" => "Offer Update Successfully", "status" => true]);
                } else {
                    echo json_encode(["message" => "Offer Not Update", "status" => false]);
                }
                break;

        }
    }
}


$obj = new control;

?>